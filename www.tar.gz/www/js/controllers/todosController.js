(function() {
  angular.module('offline')
    .controller("todosController", ["$scope","$http","$couchbase", todosController])

  function todosController($scope,$http,$couchbase) {
    var scope = $scope;
    scope.categories = [];

    
    function getCategories(_key){
       client.query.get_db_design_ddoc_view_view({db: 'sk', ddoc: 'category',view:'type',key:'"'+_key+'"',include_docs:true})
          .then(function(res){
            console.log(res);
            console.log(scope.categories);
            $scope.$apply(function(){
              scope.categories = res.obj.rows;
            });
            // for(var i=0;i<res.obj.rows.length;i++){
            //   if(res.obj.rows[i].doc._attachments){
            //     // client.attachment.get_db_doc_attachment({db: 'sk', doc:res.obj.rows[i].doc._id,attachment:'mi5.jpeg',rev:res.obj.rows[i].doc._rev})
            //     //   .then(function(res){
            //     //     console.log(res);
            //     //   },function(err){console.log(err);})
            //     $http({
            //       method:"GET",
            //       url:"http://localhost:5984/sk",
            //       doc:res.obj.rows[i].doc._id,
            //       attachment:'mi5.jpeg',
            //       rev:res.obj.rows[i].doc._rev
            //     })
            //      .then(function(res){
            //         console.log(res);
            //       },function(err){console.log(err);})
            //   }
            // }
            
          },function(err){console.log(err);})
      }

       getCategories("category");

     

  }

})();
